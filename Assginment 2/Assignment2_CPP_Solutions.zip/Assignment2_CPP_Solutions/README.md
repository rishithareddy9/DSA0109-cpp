# Assignment 2 – CO2 C++ Solutions

Each task has its own folder, `main.cpp`, and `expected_output.txt`.

## Compile and run
Use a C++17 compiler (g++):
```bash
g++ -std=c++17 -Wall -Wextra main.cpp -o program
./program
```
On Windows PowerShell:
```powershell
g++ -std=c++17 -Wall -Wextra main.cpp -o program.exe
.\program.exe
```

## Task notes
- **Task01:** Demonstrates call by value, reference, pointer, return by reference, default arguments, and the fee-concession TODO.
- **Task02:** Demonstrates safe return by reference to an array element, plus index and pointer alternatives. The dangling-reference example is commented out intentionally; do not execute undefined behaviour. Uncommenting it may produce a compiler warning.
- **Task03:** Demonstrates overloads for integer grams, double kilograms, and `Parcel`, with default arguments for express and insurance. `charge(2)` selects the integer-grams overload; `charge(2.0f)` promotes float to double.
- **Task04:** Savings account with a private fixed array of the latest ten transactions. Once full, it shifts entries and discards the oldest.
- **Task05:** Static ticket counter and array of objects; capacity is three.
- **Task06:** Friend functions access private time fields; both are marked inline. Includes same-time and across-noon checks.
- **Task07:** Day-4 redesign example: replaces O(k) shifting of retained items with an O(1) circular-buffer insertion. Both approaches retain the same latest five values.

## Important
Task 7 is an example design challenge based on Task 4's transaction-history limitation. Your report should include your own timings/measurements and explain the result. Do not claim measured timing values unless you actually run and record them.
