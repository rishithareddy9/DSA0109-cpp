#include <iostream>
using namespace std;

int& highestMark(int marks[], int size) {
    int maxIndex = 0;
    for (int i = 1; i < size; ++i) {
        if (marks[i] > marks[maxIndex]) maxIndex = i;
    }
    return marks[maxIndex]; // safe: refers to an array element
}

// Alternative: return index
int highestMarkIndex(const int marks[], int size) {
    int maxIndex = 0;
    for (int i = 1; i < size; ++i) {
        if (marks[i] > marks[maxIndex]) maxIndex = i;
    }
    return maxIndex;
}

// Alternative: return pointer
int* highestMarkPointer(int marks[], int size) {
    int maxIndex = 0;
    for (int i = 1; i < size; ++i) {
        if (marks[i] > marks[maxIndex]) maxIndex = i;
    }
    return &marks[maxIndex];
}

// DANGEROUS EXAMPLE -- intentionally not called.
// A compiler should warn: returning reference to local variable.
// int& danglingReference() {
//     int local = 50;
//     return local; // invalid after function returns; using it is undefined behaviour
// }

int main() {
    int marks[5] = {78, 92, 85, 88, 91};

    cout << "Highest mark: " << highestMark(marks, 5) << '\n';
    highestMark(marks, 5) += 2;
    cout << "After moderation: " << marks[1] << '\n';

    int index = highestMarkIndex(marks, 5);
    cout << "Index of highest mark: " << index << '\n';

    int* ptr = highestMarkPointer(marks, 5);
    cout << "Highest through pointer: " << *ptr << '\n';
    return 0;
}
