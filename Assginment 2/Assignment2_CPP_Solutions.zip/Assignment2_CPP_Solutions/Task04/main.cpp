#include <iostream>
#include <string>
using namespace std;

class SavingsAccount {
private:
    long long accountNumber;
    double balance;
    double transactions[10];
    int count;

    void addTransaction(double amount) {
        if (count < 10) {
            transactions[count++] = amount;
        } else {
            // Shift left; discard oldest transaction.
            for (int i = 1; i < 10; ++i) transactions[i - 1] = transactions[i];
            transactions[9] = amount;
        }
    }

public:
    SavingsAccount(long long number, double openingBalance)
        : accountNumber(number), balance(openingBalance), count(0) {}

    void deposit(double amount); // defined outside class
    bool withdraw(double amount); // defined outside class
    void miniStatement() const; // defined outside class
};

void SavingsAccount::deposit(double amount) {
    if (amount <= 0) return;
    balance += amount;
    addTransaction(amount);
}

bool SavingsAccount::withdraw(double amount) {
    if (amount <= 0 || amount > balance) return false;
    balance -= amount;
    addTransaction(-amount);
    return true;
}

void SavingsAccount::miniStatement() const {
    cout << "Account: " << accountNumber << '\n';
    cout << "Balance: " << balance << '\n';
    cout << "Last transactions (oldest to newest):\n";
    for (int i = 0; i < count; ++i) {
        cout << transactions[i] << '\n';
    }
}

int main() {
    SavingsAccount account(10001, 1000.0);
    account.deposit(100);
    account.withdraw(50);
    account.deposit(200);
    account.withdraw(25);
    account.miniStatement();
    return 0;
}
