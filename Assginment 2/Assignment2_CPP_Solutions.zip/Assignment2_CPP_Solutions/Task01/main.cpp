#include <iostream>
using namespace std;

// Call by value, reference and pointer
void change(int a, int& b, int* c) {
    a += 10;       // only local copy changes
    b += 10;       // caller's variable changes
    *c += 10;      // caller's variable changes
}

int& bigger(int& p, int& q) {
    return (p > q) ? p : q;
}

void show(int x, int y = 5, int z = 10) {
    cout << x + y + z << ' ';
}

// Complete-the-code: value version does not change caller
void applyByValue(long long fee, int percent) {
    fee -= fee * percent / 100;
}

// Reference version changes caller
void applyConcession(long long& fee, int percent) {
    fee -= fee * percent / 100;
}

int main() {
    int a = 1, b = 2, c = 3;
    change(a, b, &c);
    cout << a << ' ' << b << ' ' << c << '\n';

    bigger(a, c) = 100;
    cout << a << ' ' << c << '\n';

    show(1);
    show(1, 2);
    show(1, 2, 3);
    cout << '\n';

    long long hostelFee = 45000;
    applyByValue(hostelFee, 10);
    cout << "after call by value   : " << hostelFee << '\n';
    applyConcession(hostelFee, 10);
    cout << "after call by reference: " << hostelFee << '\n';
    return 0;
}
