#include <iostream>
using namespace std;

// Original approach: shift all entries when the fixed array is full.
class ShiftHistory {
    int data[5]{};
    int count = 0;
public:
    void add(int value) {
        if (count < 5) data[count++] = value;
        else {
            for (int i = 1; i < 5; ++i) data[i - 1] = data[i];
            data[4] = value;
        }
    }
    void print() const {
        for (int i = 0; i < count; ++i) cout << data[i] << ' ';
        cout << '\n';
    }
};

// Redesigned approach: circular buffer; overwrite oldest in O(1).
class CircularHistory {
    int data[5]{};
    int start = 0;
    int count = 0;
public:
    void add(int value) {
        if (count < 5) {
            data[(start + count) % 5] = value;
            ++count;
        } else {
            data[start] = value;
            start = (start + 1) % 5;
        }
    }
    void print() const {
        for (int i = 0; i < count; ++i)
            cout << data[(start + i) % 5] << ' ';
        cout << '\n';
    }
};

int main() {
    ShiftHistory original;
    CircularHistory redesigned;

    for (int value = 1; value <= 8; ++value) {
        original.add(value);
        redesigned.add(value);
    }

    cout << "Original (shift): ";
    original.print();
    cout << "Redesigned (circular): ";
    redesigned.print();
    return 0;
}
