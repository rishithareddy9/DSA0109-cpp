#include <iostream>
#include <string>
#include <memory>
#include <vector>
#include <stdexcept>

class Bill {
public:
    virtual ~Bill() = default;
    virtual double total() const = 0;
    virtual std::string type() const = 0;
};

class OutPatient : public Bill {
    double consultation, tests;
public:
    OutPatient(double c, double t) : consultation(c), tests(t) {}
    double total() const override { return consultation + tests; }
    std::string type() const override { return "OP"; }
};

class DayCareBill : public Bill {
    double packagePrice;
public:
    explicit DayCareBill(double p) : packagePrice(p) {
        if (p < 0) throw std::invalid_argument("negative package price");
    }
    double total() const override { return packagePrice; }
    std::string type() const override { return "DayCare"; }
};

class Payer {
public:
    virtual ~Payer() = default;
    virtual double covered(double amount) const = 0;
};

class SelfPay : public Payer {
public:
    double covered(double amount) const override { return amount; }
};

class CorporatePayer : public Payer {
    double percentage;
public:
    explicit CorporatePayer(double p) : percentage(p) {}
    double covered(double amount) const override { return amount * percentage / 100.0; }
};

int main() {
    std::vector<std::unique_ptr<Bill>> bills;
    bills.push_back(std::make_unique<OutPatient>(500, 1200));
    bills.push_back(std::make_unique<DayCareBill>(25000));

    SelfPay self;
    CorporatePayer corporate(80);
    for (const auto& b : bills) {
        std::cout << b->type() << " total " << b->total()
                  << " | self " << self.covered(b->total())
                  << " | corporate " << corporate.covered(b->total()) << '\n';
    }
}
