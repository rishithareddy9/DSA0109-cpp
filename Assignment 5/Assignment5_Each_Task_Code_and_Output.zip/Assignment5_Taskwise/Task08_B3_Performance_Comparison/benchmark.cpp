#include <iostream>
#include <vector>
#include <memory>
#include <chrono>
#include <string>
#include <stdexcept>
#include <cstdint>

struct Base {
    virtual ~Base() = default;
    virtual double total() const = 0;
};
struct OP : Base {
    double a, b;
    OP(double x, double y) : a(x), b(y) {}
    double total() const override { return a + b; }
};
struct IP : Base {
    double a, b;
    IP(double x, double y) : a(x), b(y) {}
    double total() const override { return a + b; }
};
struct Record {
    int type;
    double a, b;
};
volatile double sink = 0;

template<class F>
long long measure(F f) {
    auto start = std::chrono::steady_clock::now();
    sink = f();
    auto end = std::chrono::steady_clock::now();
    return std::chrono::duration_cast<std::chrono::microseconds>(end-start).count();
}

int main() {
    for (int n : {1000, 1000000, 10000000}) {
        std::vector<std::unique_ptr<Base>> poly;
        std::vector<Record> records;
        poly.reserve(n);
        records.reserve(n);
        for (int i=0; i<n; ++i) {
            double a = (i % 500) + 100, b = (i % 300) + 50;
            if (i % 2 == 0) poly.push_back(std::make_unique<OP>(a,b));
            else poly.push_back(std::make_unique<IP>(a,b));
            records.push_back({i % 2, a, b});
        }
        auto t1 = measure([&] {
            double s=0; for (const auto& p : poly) s += p->total(); return s;
        });
        auto t2 = measure([&] {
            double s=0; for (const auto& r : records) {
                switch(r.type) { case 0: s += r.a+r.b; break; case 1: s += r.a+r.b; break; }
            } return s;
        });
        std::cout << "Bills " << n << " | virtual_us " << t1
                  << " | switch_us " << t2 << '\n';
    }

    for (int invalidPercent : {0,1,50}) {
        constexpr int n = 1000000;
        int invalidCount = n * invalidPercent / 100;
        auto returnTime = measure([&] {
            long long accepted=0;
            for (int i=0;i<n;++i) {
                bool bad = i < invalidCount;
                if (!bad) ++accepted;
            }
            return static_cast<double>(accepted);
        });
        auto exceptionTime = measure([&] {
            long long accepted=0;
            for (int i=0;i<n;++i) {
                try {
                    if (i < invalidCount) throw std::runtime_error("invalid");
                    ++accepted;
                } catch (const std::exception&) {}
            }
            return static_cast<double>(accepted);
        });
        std::cout << "Invalid " << invalidPercent << "% | return_us " << returnTime
                  << " | exception_us " << exceptionTime << '\n';
    }
}
