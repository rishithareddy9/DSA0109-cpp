benchmark.cpp implements the requested virtual-vs-switch and return-code-vs-exception
measurements for 1,000, 1,000,000 and 10,000,000 bills. Run it on your own computer with:
g++ -std=c++17 -O2 -Wall -Wextra benchmark.cpp -o benchmark
./benchmark

Timing output is hardware/compiler dependent. Run and save the output on your own system
for the experimental-investigation section. This benchmark is intentionally not pre-run in
the provided package because 10 million polymorphic heap objects can exceed the execution
time limit of this environment.
