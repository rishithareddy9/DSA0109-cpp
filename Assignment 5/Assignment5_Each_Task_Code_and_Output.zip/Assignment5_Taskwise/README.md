# Assignment 5 – CO5 (Task-wise files)

Each task has a separate folder. Part A folders contain design answers, pseudocode,
complexity notes and output predictions. Part B folders contain C++ source files and
captured program output where execution was completed.

Compiler used: g++ 14.2.0. Standard: C++17.
Compile: `g++ -std=c++17 -Wall -Wextra filename.cpp -o program`
For the performance benchmark use `-O2` as required by the assignment.

Folders:
- Task01_A1_Design
- Task02_A2_Runtime_Binding
- Task03_A3_Payer_Interface
- Task04_A4_Exception_Strategy
- Task05_A5_Recovery_Rethrowing
- Task06_B1_Polymorphic_Billing
- Task07_B2_Error_Conditions
- Task08_B3_Performance_Comparison
- Task09_B4_Final_Decision

Before submission, add your name/register number, screenshots, input files and GitHub
repository link. Commit each task separately. Benchmark timings vary by machine; run the
benchmark locally and use your own measured results. The assignment's sanitizer tests
must also be run locally with -fsanitize=address.
